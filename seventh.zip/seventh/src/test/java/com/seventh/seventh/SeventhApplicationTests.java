package com.seventh.seventh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeventhApplicationTests {

	@Test
	void contextLoads() {
	}

}
